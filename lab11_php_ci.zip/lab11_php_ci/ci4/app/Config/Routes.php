<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// Mengaktifkan fitur Auto Routing
$routes->setAutoRoute(false);

// Routing untuk halaman utama
$routes->get('/', 'Home::index');

// Routing untuk halaman Page
$routes->get('/about', 'Page::about');
$routes->get('/contact', 'Page::contact');
$routes->get('/faqs', 'Page::faqs');
$routes->get('/page/tos', 'Page::tos'); 
